package com.jobportal.dao;

import com.jobportal.model.Job;
import com.jobportal.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobDAO {
    public boolean postJob(Job job) {
        String sql = "INSERT INTO jobs (title,company,location,description,posted_by) VALUES (?,?,?,?,?)";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, job.getTitle());
            ps.setString(2, job.getCompany());
            ps.setString(3, job.getLocation());
            ps.setString(4, job.getDescription());
            ps.setInt(5, job.getPostedBy());
            int n = ps.executeUpdate();
            return n>0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Job> listJobs(String keyword) {
        String sql = "SELECT * FROM jobs WHERE title LIKE ? OR company LIKE ? ORDER BY posted_at DESC";
        List<Job> list = new ArrayList<>();
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + (keyword==null?"":keyword) + "%";
            ps.setString(1, k);
            ps.setString(2, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Job j = new Job();
                j.setId(rs.getInt("id"));
                j.setTitle(rs.getString("title"));
                j.setCompany(rs.getString("company"));
                j.setLocation(rs.getString("location"));
                j.setDescription(rs.getString("description"));
                j.setPostedBy(rs.getInt("posted_by"));
                j.setPostedAt(rs.getTimestamp("posted_at"));
                list.add(j);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
