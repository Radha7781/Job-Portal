package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/jobs")
public class JobListServlet extends jakarta.servlet.http.HttpServlet {
    private final JobDAO jobDAO = new JobDAO();

    @Override
    protected void doGet(jakarta.servlet.http.HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        String q = req.getParameter("q");
        req.setAttribute("jobs", jobDAO.listJobs(q));
        req.getRequestDispatcher("/jobs.jsp").forward(req, resp);
    }
}
