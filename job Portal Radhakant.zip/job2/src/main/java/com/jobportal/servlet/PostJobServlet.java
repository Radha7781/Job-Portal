package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/postjob")
public class PostJobServlet extends HttpServlet {
    private final JobDAO jobDAO = new JobDAO();

    @Override
    protected void doPost(jakarta.servlet.http.HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect("login.html");
            return;
        }
        User u = (User) session.getAttribute("user");
        Job j = new Job();
        j.setTitle(req.getParameter("title"));
        j.setCompany(req.getParameter("company"));
        j.setLocation(req.getParameter("location"));
        j.setDescription(req.getParameter("description"));
        j.setPostedBy(u.getId());
        boolean ok = jobDAO.postJob(j);
        if (ok) resp.sendRedirect("jobs.jsp?msg=posted");
        else resp.sendRedirect("postjob.html?err=failed");
    }
}
