# Job Portal (Maven + Java Servlets)

Simple job search portal implemented with Java Servlets, JSP/HTML front-end and MySQL database.

## How to run

1. Install Java 17+, Maven, and MySQL.
2. Create a database and user. Example:
```sql
CREATE DATABASE job_portal;
CREATE USER 'jobuser'@'localhost' IDENTIFIED BY 'jobpass';
GRANT ALL PRIVILEGES ON job_portal.* TO 'jobuser'@'localhost';
```
3. Run the SQL script `sql/schema.sql` to create tables.
4. Update JDBC URL, username, and password in `src/main/java/com/jobportal/util/DBUtil.java`.
5. Build: `mvn clean package`
6. Deploy `target/job-portal.war` to a servlet container (Tomcat 10+, Pay attention to Jakarta namespace).
7. Open `http://localhost:8080/job-portal/`

## Features

- User registration & login (basic)
- Post job (employer)
- List jobs (searchable by keyword)
- Simple DAO layer using JDBC

This is a starter template. Extend it as needed.
